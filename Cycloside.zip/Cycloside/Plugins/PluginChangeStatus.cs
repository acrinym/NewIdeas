namespace Cycloside.Plugins;

public enum PluginChangeStatus
{
    None,
    New,
    Updated
}
