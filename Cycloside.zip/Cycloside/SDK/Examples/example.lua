print("Hello from Lua")
return os.date()
