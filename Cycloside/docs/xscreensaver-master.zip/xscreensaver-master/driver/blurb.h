/* progname plus timestamp */

#ifndef __BLURB_H__
#define __BLURB_H__

extern const char *progname;
extern int verbose_p;
extern const char *blurb (void);

#endif /*  __BLURB_H__ */

