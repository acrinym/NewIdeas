//
// Created by Dan Walmsley on 06/05/2022.
// Copyright (c) 2022 Avalonia. All rights reserved.
//

#define IS_NSPANEL

#include "AvnWindow.mm"

