#define COM_GUIDS_MATERIALIZE
#include "avalonia-native.h"
