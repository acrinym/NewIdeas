using Android.Views;

namespace Avalonia.Android.Platform.Specific
{
    public interface IAndroidView
    {
        View View { get; }
    }
}
