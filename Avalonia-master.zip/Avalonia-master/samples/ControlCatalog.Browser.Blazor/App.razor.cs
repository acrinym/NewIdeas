using System;
using System.Threading.Tasks;
using Avalonia;
using Avalonia.Browser.Blazor;

namespace ControlCatalog.Browser.Blazor;

public partial class App
{
}
