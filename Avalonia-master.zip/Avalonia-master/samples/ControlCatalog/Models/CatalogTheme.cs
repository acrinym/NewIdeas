﻿namespace ControlCatalog.Models
{
    public enum CatalogTheme
    {
        Fluent,
        Simple
    }
}
