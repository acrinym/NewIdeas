﻿using Avalonia.Controls;

namespace ControlCatalog.Pages
{
    public partial class RelativePanelPage : UserControl
    {
        public RelativePanelPage()
        {
            InitializeComponent();
        }
    }
}
