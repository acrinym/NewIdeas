using Avalonia.Controls;

namespace IntegrationTestApp.Pages;

public partial class ContextMenuPage : UserControl
{
    public ContextMenuPage()
    {
        InitializeComponent();
    }
}
