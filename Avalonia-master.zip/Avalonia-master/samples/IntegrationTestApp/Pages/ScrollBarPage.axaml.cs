using Avalonia.Controls;

namespace IntegrationTestApp.Pages;

public partial class ScrollBarPage : UserControl
{
    public ScrollBarPage()
    {
        InitializeComponent();
    }
}
