using Avalonia.Controls;

namespace IntegrationTestApp.Pages;

public partial class CheckBoxPage : UserControl
{
    public CheckBoxPage()
    {
        InitializeComponent();
    }
}
