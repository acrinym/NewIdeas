using Avalonia.Controls;

namespace IntegrationTestApp.Pages;

public partial class AutomationPage : UserControl
{
    public AutomationPage()
    {
        InitializeComponent();
    }
}
