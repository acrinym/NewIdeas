using Avalonia.Controls;

namespace IntegrationTestApp.Pages;

public partial class ButtonPage : UserControl
{
    public ButtonPage()
    {
        InitializeComponent();
    }
}
