using Avalonia.Controls;

namespace IntegrationTestApp.Pages;

public partial class RadioButtonPage : UserControl
{
    public RadioButtonPage()
    {
        InitializeComponent();
    }
}
