using MiniMvvm;

namespace BindingDemo.ViewModels
{

}
