using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace SafeAreaDemo.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            AvaloniaXamlLoader.Load(this);
        }
    }
}
