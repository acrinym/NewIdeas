using Avalonia.Controls;

namespace VirtualizationDemo.Views;

public partial class ChatPageView : UserControl
{
    public ChatPageView()
    {
        InitializeComponent();
    }
}
