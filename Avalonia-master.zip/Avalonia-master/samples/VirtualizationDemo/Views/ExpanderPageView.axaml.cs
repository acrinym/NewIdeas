using Avalonia;
using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace VirtualizationDemo.Views;

public partial class ExpanderPageView : UserControl
{
    public ExpanderPageView()
    {
        InitializeComponent();
    }
}