using Avalonia.Controls;
using Avalonia.Markup.Xaml;

namespace SingleProjectSandbox;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
