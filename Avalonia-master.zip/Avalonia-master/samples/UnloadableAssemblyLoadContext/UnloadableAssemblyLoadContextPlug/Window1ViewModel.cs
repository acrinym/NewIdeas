﻿

namespace UnloadableAssemblyLoadContextPlug;

public partial class Window1ViewModel 
{
    public string Text { get; set; } = "12";
}
