﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.Primitives;

namespace UnloadableAssemblyLoadContextPlug;

public class TestControl : TemplatedControl
{
}

